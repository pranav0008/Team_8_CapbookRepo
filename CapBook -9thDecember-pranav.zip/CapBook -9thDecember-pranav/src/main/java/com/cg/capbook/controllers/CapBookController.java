package com.cg.capbook.controllers;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.cg.capbook.beans.User;
import com.cg.capbook.exceptions.RequestAlreadySentException;
import com.cg.capbook.exceptions.SameUserIdException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.services.UserServices;

@RestController
@CrossOrigin()
public class CapBookController {
	@Autowired 
	private UserServices userServices;
	@RequestMapping(value="/register", method=RequestMethod.POST, consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> registerUserAction(@RequestBody User user) {
		userServices.registerUser(user);
		return new ResponseEntity<String>("User successfully added", HttpStatus.OK);
	}
	@RequestMapping(value="/getAllUsers",method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<List<User>> getUserAction() throws UserDetailsNotFoundException {
		List<User> users=userServices.getAllUserDetails();
		return new ResponseEntity<List<User>>(users, HttpStatus.OK);
	}
	@RequestMapping(value="/getUserDetails",method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<User> getUserAction(@RequestParam("userId") int userId ) throws UserDetailsNotFoundException {
		User user=userServices.getUserDetails(userId);
		return new ResponseEntity<User>(user, HttpStatus.OK);
	}
	@RequestMapping(value="/editUserDetails",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> editUserAction(@RequestBody User user) {
		user=userServices.editUserDetails(user);
		return new ResponseEntity<User>(user, HttpStatus.OK);
	}
	@RequestMapping(value="/deleteUserDetails",method=RequestMethod.DELETE,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> deleteUserAction(@RequestParam("userId") int userId ) throws UserDetailsNotFoundException {
		userServices.deleteUserAccount(userId);
		return new ResponseEntity<String>("User details have been deleted successfully",HttpStatus.OK);
	}
	@RequestMapping(value="/getUserByName", method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<User>> getAllUserNames(@RequestParam("firstName") String firstName) throws UserDetailsNotFoundException{
		List<User> users = userServices.getAllUserFewDetails(firstName);
		return new ResponseEntity<List<User>>(users,HttpStatus.OK);
	}
	@RequestMapping(value="/addBulkUserDetails",consumes=MediaType.APPLICATION_JSON_VALUE,
			method=RequestMethod.POST)
	public ResponseEntity<String> addBulkUserDetails(@RequestBody ArrayList<User> users){
		for(User user:users)
			userServices.registerUser(user);
		return new ResponseEntity<>("user details successfully added",HttpStatus.OK);
	}
	@RequestMapping(value="/sendRequest",consumes = MediaType.APPLICATION_JSON_VALUE,
			method=RequestMethod.POST)
	public ResponseEntity<String> sendRequest(@RequestParam("userIdSender") int userIdSender,
			@RequestParam("userIdreceiver") int userIdreceiver) throws UserDetailsNotFoundException, SameUserIdException, RequestAlreadySentException{
		userServices.sendFriendRequest(userIdSender, userIdreceiver);
		return new ResponseEntity<>("request sent",HttpStatus.OK);
	}
	@RequestMapping(value="/acceptRequest",consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
			method=RequestMethod.POST)
	public ResponseEntity<String> acceptRequest(@RequestParam("userIdSender") int userIdSender,
			@RequestParam("userIdreceiver") int userIdreceiver) throws UserDetailsNotFoundException{
		userServices.acceptFriendRequest(userIdSender, userIdreceiver);
		return new ResponseEntity<>("request accepted",HttpStatus.OK);
	}
	@RequestMapping(value="/cancelRequest",consumes = MediaType.APPLICATION_JSON_VALUE,
			method=RequestMethod.POST)
	public ResponseEntity<String> cancelRequest(@RequestParam("userIdSender") int userIdSender,
			@RequestParam("userIdreceiver") int userIdreceiver) throws UserDetailsNotFoundException{
		userServices.cancelSentRequest(userIdSender, userIdreceiver);
		return new ResponseEntity<>("request cancelled",HttpStatus.OK);
	}
	@RequestMapping(value="/rejectRequest",consumes = MediaType.APPLICATION_JSON_VALUE,
			method=RequestMethod.POST)
	public ResponseEntity<String> rejectRequest(@RequestParam("userIdSender") int userIdSender,
			@RequestParam("userIdreceiver") int userIdreceiver) throws UserDetailsNotFoundException{
		userServices.rejectRequest(userIdSender, userIdreceiver);
		return new ResponseEntity<>("request rejected",HttpStatus.OK);
		}
	@RequestMapping(value="/friendRequestsList",consumes = MediaType.APPLICATION_JSON_VALUE,
			method=RequestMethod.GET)
	public ResponseEntity<List<User>> getfriendRequestList(@RequestParam("userIdreceiver") int userIdreceiver) throws UserDetailsNotFoundException{
		List<User> users = userServices.getFriendRequests(userIdreceiver);
		return new ResponseEntity<List<User>>(users,HttpStatus.OK);
	}
	@RequestMapping(value="/friendsList",consumes = MediaType.APPLICATION_JSON_VALUE,
			method=RequestMethod.GET)
	public ResponseEntity<List<User>> getfriendsList(@RequestParam("userId") int userId, @RequestParam("friendId") int friendId) throws UserDetailsNotFoundException{
		List<User> users = userServices.getFriendsList(userId, friendId);
		return new ResponseEntity<List<User>>(users,HttpStatus.OK);
	}
	
	
}