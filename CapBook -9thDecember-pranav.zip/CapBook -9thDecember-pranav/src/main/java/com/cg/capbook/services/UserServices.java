package com.cg.capbook.services;
import java.util.ArrayList;
import java.util.List;

import com.cg.capbook.beans.FriendList;
import com.cg.capbook.beans.User;
import com.cg.capbook.exceptions.RequestAlreadySentException;
import com.cg.capbook.exceptions.SameUserIdException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;

public interface UserServices {
	
	public User registerUser(User user) ;
	public User getUserDetails(int userId) throws UserDetailsNotFoundException;
	public User editUserDetails(User user);
	public boolean deleteUserAccount(int userId) throws UserDetailsNotFoundException;
	public List<User> getAllUserDetails();
	public List<User> getAllUserFewDetails(String firstName) throws UserDetailsNotFoundException;
	public boolean sendFriendRequest(int userIdSender,int userIdreceiver) throws UserDetailsNotFoundException, SameUserIdException, RequestAlreadySentException;

	public boolean acceptFriendRequest(int userIdSender,int userIdreceiver) throws UserDetailsNotFoundException;
	
	public boolean cancelSentRequest(int userIdSender,int userIdreceiver)throws UserDetailsNotFoundException;
	
	public boolean rejectRequest(int userIdSender,int userIdreceiver) throws UserDetailsNotFoundException;

	public List<User> getFriendsList(int userId, int friendId);
	public List<User> getFriendRequests(int userIdreceiver) throws UserDetailsNotFoundException;
}
