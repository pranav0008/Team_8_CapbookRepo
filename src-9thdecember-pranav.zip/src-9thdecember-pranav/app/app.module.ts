import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserWallComponent } from './userWall/user-wall.component';
import { LoginUserComponent } from './LoginUser/login-user.component';
import { RegisterUserComponent } from './RegisterUser/register-user.component';
import { RouterModule } from '@angular/router';
import {FormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { WelcomeComponent } from './welcome/welcome.component';
import { AllUsersComponent } from './AllUsers/all-users.component';
import { FriendRequestsComponent } from './FriendRequests/friend-requests.component';

@NgModule({
  declarations: [
    AppComponent,
    UserWallComponent,
    LoginUserComponent,
    RegisterUserComponent,
    WelcomeComponent,
    AllUsersComponent,
    FriendRequestsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path:'register', component:RegisterUserComponent},
      {path: 'wall', component:UserWallComponent},
      {path:'welcome', component:WelcomeComponent},
      {path:'login', component:LoginUserComponent},
      {path:'allUsers',component:AllUsersComponent},
      {path:'friendRequestsList',component:FriendRequestsComponent}
  ]),
],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
