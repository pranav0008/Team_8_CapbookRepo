import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import {ActivatedRoute,Router} from '@angular/router';
import { User } from '../user';


@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {

  pageTitle1:string="Already a user?"
  pageTitle2:string="Sign in here"
  errorMessage:string
  public user:User

  constructor(private router:Router,private userService : UserService) { }

  ngOnInit() {
  }

  onClick(emailId:string,password:string){
    this.userService.loginUser(emailId, password).subscribe(
      ()=>{},
      message=>{
        this.errorMessage=message
      }
    )
    this.router.navigate(['/wall',emailId])
    
  }
}