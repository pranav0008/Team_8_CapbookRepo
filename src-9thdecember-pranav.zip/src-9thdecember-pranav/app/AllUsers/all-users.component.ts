import { Component, OnInit, ViewChild} from '@angular/core';
import { UserService } from '../Services/user.service';
import { stringify } from '@angular/compiler/src/util';
import { User } from '../user';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-all-users',
  templateUrl: './all-users.component.html',
  styleUrls: ['./all-users.component.css']
})
export class AllUsersComponent implements OnInit {
  _listFilter:string=''
  constructor(private router:Router,private userService: UserService, private route:ActivatedRoute) { 
    this._listFilter=""
  }

  get listFilter(): string{
    return this._listFilter;
  }
  set listFilter(value: string){
    this._listFilter=value;
    this.userList=this.userList?this.doUserFilter(this._listFilter):this.users
  }
  doUserFilter(filterBy:string):User[]{
    filterBy=filterBy.toLowerCase();
    return this.users.filter(user=> user.firstName.toLowerCase().indexOf(filterBy)!==-1);
  }
  error:string;
  userList:User[];
  users:User[];
  user:User;
  successMessage:string
  errorMessage:string
  userIdSender:string
    ngOnInit() {
      const userId = this.route.snapshot.paramMap.get("userId");
      this.userIdSender=userId;
      this.userService.getAllUsers().subscribe(
        tempUsers=>{
          this.users=tempUsers;
          this.userList=this.users;
        },
        error=>{
          this.error=error;
        }
      )
  }
addFriend(userIdSender:string,userIdreceiver:string){
this.userService.sendFriendRequest(userIdSender,userIdreceiver).subscribe(
message=>{
  this.successMessage=message;
},
errorMessage=>{
  this.errorMessage=errorMessage;
})}

cancelsentRequest(userIdSender:string,userIdreceiver:string){
  this.userService.cancelSentRequest(userIdSender,userIdreceiver).subscribe(
    message=>{
      this.successMessage=message;
    },
    errorMessage=>{
      this.errorMessage=errorMessage;
    })
}
}

