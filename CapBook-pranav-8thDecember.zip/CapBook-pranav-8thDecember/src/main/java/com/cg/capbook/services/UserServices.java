package com.cg.capbook.services;
import java.util.ArrayList;
import java.util.List;

import com.cg.capbook.beans.FriendList;
import com.cg.capbook.beans.User;
import com.cg.capbook.exceptions.RequestAlreadySentException;
import com.cg.capbook.exceptions.SameUserIdException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;

public interface UserServices {
	
	public User registerUser(User user) ;
	public User getUserDetails(int userId) throws UserDetailsNotFoundException;
	public User editUserDetails(User user);
	public boolean deleteUserAccount(int userId) throws UserDetailsNotFoundException;
	public List<User> getAllUserDetails();
	public List<User> getAllUserFewDetails(String firstName) throws UserDetailsNotFoundException;
	public boolean sendFriendRequest(int userIdsent,int userIdrecieved) throws UserDetailsNotFoundException, SameUserIdException, RequestAlreadySentException;

	public boolean acceptFriendRequest(int userIdsent,int userIdrecieved) throws UserDetailsNotFoundException;
	
	public boolean cancelSentRequest(int userIdsent,int userIdrecieved)throws UserDetailsNotFoundException;
	
	public boolean rejectRequest(int userIdsent,int userIdrecieved) throws UserDetailsNotFoundException;

	public List<FriendList> getFriendsList(int userId, int friendId);
}
