package com.cg.capbook.daoservices;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capbook.beans.FriendList;
import com.cg.capbook.beans.User;
@Qualifier("JpaRepository")
public interface UserDAO extends JpaRepository<User, Integer>{

@Query("SELECT a.firstName,a.lastName,a.address.city FROM User a WHERE a.firstName=:firstName")	
List<User>	getAllUsersByNames(@Param("firstName")String firstName);


/*@Query("SELECT a.firstName,a.lastName,a.gender FROM User a WHERE a.FriendList.friendId=:friendId"
		+ " and a.userId=:userId")
List<FriendList> getfriendsDetails(@Param("userId")int userId,@Param("friendId") int friendId);
*/



/*@Query("UPDATE User a SET a.friendId=:")
User requestGetsAccepted(@Param("userIdSender")int userIdSender, @Param("userIdreceiver") int userIdreceiver);
*/
}