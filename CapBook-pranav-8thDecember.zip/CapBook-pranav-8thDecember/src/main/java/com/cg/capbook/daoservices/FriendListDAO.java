package com.cg.capbook.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capbook.beans.FriendList;

public interface FriendListDAO extends JpaRepository<FriendList, Integer> {

	@Transactional
	@Modifying
	@Query("UPDATE FriendList a SET a.friendId=:userIdSender WHERE a.user.userId=:userIdreceiver")
	int acceptRequest(@Param("userIdSender")int userIdSender, @Param("userIdreceiver") int userIdreceiver);

	@Transactional
	@Modifying
	@Query("UPDATE FriendList a SET a.friendId=:userIdreceiver WHERE a.user.userId=:userIdSender")
	int requestGetsAccepted(@Param("userIdSender")int userIdSender, @Param("userIdreceiver") int userIdreceiver);

	
}
